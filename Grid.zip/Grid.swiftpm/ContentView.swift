import SwiftUI
struct ContentView: View {
    @State private var gridColumns: [GridItem] = [GridItem(.adaptive(minimum: 380), spacing: 10)]
    var body: some View {
        ScrollView {
            LazyVGrid(columns: gridColumns) {
                HStack {Spacer()}
                .frame(width: .infinity, height: 400)
                .background(Color.red)
                
                HStack {Spacer()}
                .frame(width: .infinity, height: 400)
                .background(Color.green)
                
                HStack {Spacer()}
                    .frame(width: .infinity, height: 400)
                    .background(Color.gray)
                
                HStack {Spacer()}
                    .frame(width: .infinity, height: 400)
                    .background(Color.orange)
                
                HStack {Spacer()}
                    .frame(width: .infinity, height: 400)
                    .background(Color.gray)
                
                HStack {Spacer()}
                    .frame(width: .infinity, height: 400)
                    .background(Color.cyan)
            }
            
        }
    }
}
